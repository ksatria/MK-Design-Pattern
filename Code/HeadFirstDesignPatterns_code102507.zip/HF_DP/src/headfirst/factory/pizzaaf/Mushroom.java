package headfirst.factory.pizzaaf;

public class Mushroom implements Veggies {

	public String toString() {
		return "Mushrooms";
	}
}
